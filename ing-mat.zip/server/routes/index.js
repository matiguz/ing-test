const event = require('./event');

module.exports = (router) => {
    event(router)
 }
